# testing-turing
Ejerciicio maquina de turing para la asignatura de compiladores Universidad del Magdalena, en donde se practica evaluando el ejercicio https://docs.google.com/presentation/d/1T1vDcipm_KLt9oSKuKy5JP7aM58f_iBK4KYjui7lUfI/edit
de la diapositiva 134
