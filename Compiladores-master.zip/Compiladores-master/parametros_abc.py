from sys import argv

string, cadena = argv

print (argv)