# TuringMachine
Pagina web donde se simula el funcionamiento de la maquina de Turing haciendo uso de html, css y javascript.
La maquina recibe una palabra formada solo por las letras a y b, luego sobre escribe cada letra por una a, y se mueve hacia la derecha, hasta que llega a un espacio vacío y se mueve hacia la izquierda, cambiando las letras a por a. Finalmente cuando llega a un espacio vacío se mueve hacia la derecha, terminando en el carácter donde inició.
